#include"time_sync.h"
#include"ble_node_context.h"
#include"time.h"
#include <sys/time.h>



 void utc_normal_message_action_from_Peripheral(ble_node_context_t * ctx){


  switch(ctx->utc_time_update.ble_message_type){


    case BLE_NORMAL_MESSAGE:
    MY_LOGI(LOG_TAG_NTP,"BLE_NORMAL_MESSAGE");

    break;


    case BLE_TIME_REQUEST_MESSAGE:

     MY_LOGI(LOG_TAG_NTP,"BLE_TIME_REQUEST_MESSAGE");

     if(ctx->utc_time_update.ble_time_update==TIME_UPDATED){


        time_t now;
        struct tm utc_time;

        time(&now);  // Get the current time in seconds since the epoch
        gmtime_r(&now, &utc_time);

        ESP_LOGI(LOG_TAG_NTP ,"UTC when connected to NTP server: %04d-%02d-%02d %02d:%02d:%02d",
            utc_time.tm_year + 1900,
            utc_time.tm_mon + 1,
            utc_time.tm_mday,
            utc_time.tm_hour,
            utc_time.tm_min,
            utc_time.tm_sec
        );

      // ctx->utc_time_update.ble_time_update = TIME_UPDATED;       // central time updated 
       ctx->utc_time_update.utc_seconds =(uint8_t)utc_time.tm_sec;      // only seconds are required to send to peripheral 

       ctx->raw_ext_adv_data_2m[EXT_ADV_MESSAGE_TYPE_INDEX] = BLE_TIME_RESPONSE_MESSAGE;            // set the message type to time response
       ctx->raw_ext_adv_data_2m[EXT_ADV_TIME_STATUS_INDEX] = TIME_UPDATED;                          // set the time status to updated
       ctx->raw_ext_adv_data_2m[EXT_ADV_UTC_SECONDS_INDEX] = ctx->utc_time_update.utc_seconds;      // set the UTC seconds


     }

     else
    {
        ctx->raw_ext_adv_data_2m[EXT_ADV_MESSAGE_TYPE_INDEX] =  BLE_TIME_RESPONSE_MESSAGE;
        ctx->raw_ext_adv_data_2m[EXT_ADV_TIME_STATUS_INDEX] =   TIME_NONE;
        ctx->raw_ext_adv_data_2m[EXT_ADV_UTC_SECONDS_INDEX] =   0;
    }
    break;

    default:

    break;


}


}



 void utc_normal_message_action_from_Central(ble_node_context_t * ctx){

 // struct tm utc_time;
  //time_t now;
  struct timeval tv;



  switch(ctx->utc_time_update.ble_message_type){


      case BLE_NORMAL_MESSAGE:
      MY_LOGI(LOG_TAG_NTP,"BLE_NORMAL_MESSAGE");

      break;


      case BLE_TIME_RESPONSE_MESSAGE:

      MY_LOGI(LOG_TAG_NTP,"BLE_TIME_RESPONSE_MESSAGE");

      if(ctx->utc_time_update.ble_time_update==TIME_NONE){

        gettimeofday(&tv, NULL);

        tv.tv_sec =tv.tv_sec - (tv.tv_sec % 60) + ctx->utc_time_update.utc_seconds;

        tv.tv_usec = 0;

        if (settimeofday(&tv, NULL) != 0)
        {
            MY_LOGE(LOG_TAG_NTP, "settimeofday failed");
        }

      /*  time(&now);  // Get the current time in seconds since the epoch
        gmtime_r(&now, &utc_time);
       
        MY_LOGI(LOG_TAG_NTP ,"UTC: %04d-%02d-%02d %02d:%02d:%02d",
            utc_time.tm_year + 1900,
            utc_time.tm_mon + 1,
            utc_time.tm_mday,
            utc_time.tm_hour,
            utc_time.tm_min,
            utc_time.tm_sec
        );
  */


      }

      else
      {
          
         MY_LOGI(LOG_TAG_NTP,"TIME_UPDATED");
        
      }
      break;

      default:

    break;


}


}
 