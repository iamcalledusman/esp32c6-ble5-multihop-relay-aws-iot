#include "ntp.h"
#include "common_mode.h"
#include "ble_node_context.h"
#define LOCAL_NTP_SERVER_IP "192.168.100.142"   // Replace with your PC IPv4





static void time_sync_notification_cb(struct timeval *tv)
{
    ESP_LOGI(LOG_TAG_NTP , "NTP synchronization completed");
}

static void start_local_sntp(void)
{
    ESP_LOGI(LOG_TAG_NTP , "Starting SNTP server: %s", LOCAL_NTP_SERVER_IP);

    esp_sntp_setoperatingmode(SNTP_OPMODE_POLL);
    esp_sntp_set_sync_mode(SNTP_SYNC_MODE_IMMED);
    esp_sntp_setservername(0, LOCAL_NTP_SERVER_IP);
    esp_sntp_set_time_sync_notification_cb(time_sync_notification_cb);
    esp_sntp_init();
}


static bool wait_for_time_sync(void)
{
    for (int retry = 0; retry < 20; retry++) {

        if (esp_sntp_get_sync_status() == SNTP_SYNC_STATUS_COMPLETED) {
            return true;
        }

        ESP_LOGI(LOG_TAG_NTP , "Waiting for NTP response... %d/20", retry + 1);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }

    return false;
}



static void print_utc_time(ble_node_context_t * ctx)
{

    if (ctx == NULL) {
        ESP_LOGE(LOG_TAG_NTP, "Invalid BLE node context");
        return;
    }

    time_t now;
    struct tm utc_time;

    time(&now);  // Get the current time in seconds since the epoch
    gmtime_r(&now, &utc_time);

    ESP_LOGI(LOG_TAG_NTP ,"UTC when connected to NTP server: %04d-%02d-%02d %02d:%02d:%02d",
        utc_time.tm_year + 1900,
        utc_time.tm_mon + 1,
        utc_time.tm_mday,
        utc_time.tm_hour,
        utc_time.tm_min,
        utc_time.tm_sec
    );

    ctx->utc_time_update.ble_time_update = TIME_UPDATED;       // central time updated 
   //ctx->utc_time_update.utc_seconds =(uint8_t)utc_time.tm_sec;      // only seconds are required to send to peripheral 

 //   ESP_LOGI(LOG_TAG_NTP, "Unix timestamp: %lld", (long long)now);
}


void obtain_and_print_ntp_time(void)
{
    ble_node_context_t *ctx = &ble_node_ctx;

    /*
     * Call this only after Wi-Fi is connected
     * and the ESP32 has received an IP address.
     */

    start_local_sntp();

    if (wait_for_time_sync()) {
       print_utc_time(ctx);
    } else {
        ESP_LOGE(LOG_TAG_NTP, "Failed to obtain time from local NTP server");
    }
}
