
#ifndef LOG_H
#define LOG_H

/* typedef enum{

    Print_No_Log =0,
    Print_Selected_Log=1,
    Print_All_Log = 2
    

}Log_enable_disable;

extern Log_enable_disable current_log_level;
 */


#include "esp_log.h"


// Define log levels
typedef enum {
    Print_None = 0,
    Print_Error,
    Print_Warning,
    Print_Selected_Log,
    Print_Debug_log,
    Print_All_log,
} log_level_t;

// Global variable to control current log level
extern log_level_t current_log_level;

// Custom logging macros
#define MY_LOGE(tag, fmt, ...) do { \
    if (current_log_level >= Print_Error) \
        ESP_LOGE(tag, fmt, ##__VA_ARGS__); \
} while (0)

#define MY_LOGW(tag, fmt, ...) do { \
    if (current_log_level >= Print_Warning) \
        ESP_LOGW(tag, fmt, ##__VA_ARGS__); \
} while (0)

#define MY_LOGI(tag, fmt, ...) do { \
    if (current_log_level >= Print_Selected_Log) \
        ESP_LOGI(tag, fmt, ##__VA_ARGS__); \
} while (0)

#define MY_LOGD(tag, fmt, ...) do { \
    if (current_log_level >= Print_Debug_log) \
        ESP_LOGD(tag, fmt, ##__VA_ARGS__); \
} while (0)

#define MY_LOGV(tag, fmt, ...) do { \
    if (current_log_level >= Print_All_log) \
        ESP_LOGV(tag, fmt, ##__VA_ARGS__); \
} while (0)



#endif // LOG_H