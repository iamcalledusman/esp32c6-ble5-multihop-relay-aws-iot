#ifndef NTP_H
#define NTP_H

#include "esp_sntp.h"
#include <time.h>
#include <sys/time.h>


void obtain_and_print_ntp_time(void);

#endif